package ppj.assignments.writer;

public interface Writer {

    void write(String message);
}
